"""NC A&T College of Engineering course recommendation prototype.

Seed data is transcribed from the official 2025 CS Undergraduate Handbook.
The schema has all College of Engineering undergraduate programs, while only
CS handbook courses are populated with course-level data at this checkpoint.
"""
from pathlib import Path
import csv, json, sqlite3

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / 'ncat_coe_courses.sqlite'
CSV_PATH = ROOT / 'courses.csv'
SQL_PATH = ROOT / 'ncat_coe_course_database.sql'

PROGRAMS = [
 ('BS-AE','Architectural Engineering'),('BS-CE','Civil Engineering'),
 ('BS-CS','Computer Science'),('BS-ME','Mechanical Engineering'),
 ('BS-MEA','Mechanical Engineering (Aerospace)'),('BS-ISE','Industrial and Systems Engineering'),
 ('BS-EE','Electrical Engineering'),('BS-CpE','Computer Engineering'),
 ('BS-BIOE-G','Bioengineering (General)'),('BS-BIOE-I','Bioengineering (Innovation)'),
 ('BS-BE-BP','Biological Engineering (Bioprocess Engineering)'),
 ('BS-BE-NR','Biological Engineering (Natural Resources Engineering)'),
 ('BS-CHE','Chemical Engineering')]

# (course_code, title, credits, category, keywords)
COURSES = [
 ('GEEN 111','College of Engineering Colloquium',1,'required','engineering,career'),
 ('COMP 121','Computer Science Freshmen Colloquium',1,'required','career'),
 ('COMP 163','Introduction to Computer Programming',3,'required','programming,software'),
 ('COMP 167','Computer Programming Design',3,'required','programming,software'),
 ('COMP 180','Discrete Structures',3,'required','theory,math'),
 ('COMP 267','Data Base Design',3,'required','database,data'),
 ('COMP 200','Computer Science Sophomore Colloquium',1,'required','career'),
 ('COMP 280','Data Structures',3,'required','programming,algorithms'),
 ('COMP 285','Design and Analysis of Algorithms',3,'required','algorithms,theory'),
 ('COMP 300','Computer Science Junior Colloquium',1,'required','career'),
 ('COMP 322','Internet Systems',3,'required','networks,systems'),
 ('COMP 350','Operating Systems',3,'required','systems'),
 ('COMP 360','Principles of Programming Languages',3,'required','programming,theory'),
 ('COMP 365','Artificial Intelligence and Machine Learning',3,'required','ai,machine learning,data'),
 ('COMP/ECEN 375','Computer Architecture and Organization',3,'required','systems,hardware'),
 ('COMP 385','Theory of Computing',3,'required','theory'),
 ('COMP 390','Social Implications of Computing',3,'required','ethics,society'),
 ('COMP 410','Software Engineering',3,'required','software,teamwork'),
 ('COMP 476','Networked Computer Systems',3,'required','networks,systems'),
 ('COMP 495','Senior Project I',3,'required','software,teamwork'),
 ('COMP 496','Senior Project II',3,'required','software,teamwork'),
 ('COMP 320','Fundamentals of Cybersecurity',None,'elective','security,cybersecurity'),
 ('COMP 321','Computer System Security',None,'elective','security,cybersecurity,systems'),
 ('COMP 323','Introduction to Health Care Information Systems',None,'elective','health,data'),
 ('COMP 340','Game Intelligence',None,'elective','games,ai'),
 ('COMP 356','Computational Hip-Hop and Object-Oriented Design',None,'elective','programming,design'),
 ('COMP 361','Data Analytics in Python',None,'elective','data,analytics,python'),
 ('COMP 363','Object Oriented Programming',None,'elective','programming'),
 ('COMP 368','Object-Oriented Software Development',None,'elective','software,design'),
 ('COMP 420','Applied Network Security',None,'elective','security,cybersecurity,networks'),
 ('COMP 421','Security Management for Information Systems',None,'elective','security,cybersecurity,management'),
 ('COMP 422','Information Privacy and Security',None,'elective','security,privacy'),
 ('COMP 423','Web Security',None,'elective','security,cybersecurity,web'),
 ('COMP 440','Game Design',None,'elective','games,design'),
 ('COMP 454','Virtual and Augmented Reality',None,'elective','games,graphics'),
 ('COMP 469','Introduction to Parallel Programming',None,'elective','programming,systems'),
 ('COMP 494','Independent Study',None,'elective','research'),
 ('COMP 411','Introduction to System Testing and Evaluation',None,'elective','software,testing'),
 ('COMP 452','Network Science',None,'elective','networks,data'),
 ('COMP 453','Introduction to Computer Graphics',None,'elective','graphics,games'),
 ('COMP 463','Introduction to Compiler Design',None,'elective','programming,systems'),
 ('COMP 468','Introduction to Data Mining',None,'elective','data,analytics'),
 ('COMP 485','Special Topics in Computer Science',None,'elective','research'),
 ('BUAN 335','Management of Information Resources',None,'outside elective','management,data'),
 ('ECEN 427','Introduction to Microprocessors',None,'outside elective','hardware,systems'),
 ('ISEN 415','Discrete Event Systems Model Simulation',None,'outside elective','simulation,systems'),
 ('MATH 365','Introduction to Data Science',None,'outside elective','data,analytics'),
 ('CST 340','Introduction to Mainframe Operations',None,'outside elective','systems')]

# (course, rule type, prerequisite course, logic group, rule text)
PREREQUISITES = [
 ('COMP 320','standing',None,'all','Junior standing'),
 ('COMP 321','course','COMP 285','all','COMP 285'),
 ('COMP 323','standing',None,'all','Junior standing'),
 ('COMP 340','course','COMP 280','all','COMP 280'),
 ('COMP 356','course','COMP 163','any','COMP 163 or instructor permission'),
 ('COMP 356','permission',None,'any','COMP 163 or instructor permission'),
 ('COMP 361','course','COMP 280','all','COMP 280, MATH 351, and a statistics elective'),
 ('COMP 361','course','MATH 351','all','COMP 280, MATH 351, and a statistics elective'),
 ('COMP 361','other',None,'all','Statistics elective'),
 ('COMP 363','course','COMP 280','all','COMP 280'),
 ('COMP 368','course','COMP 280','all','COMP 280'),
 ('COMP 420','course','COMP 280','any','COMP 280 or instructor permission'),
 ('COMP 420','permission',None,'any','COMP 280 or instructor permission'),
 ('COMP 421','course','COMP 285','all','COMP 285'),
 ('COMP 422','course','COMP 280','any','COMP 280 or instructor permission'),
 ('COMP 422','permission',None,'any','COMP 280 or instructor permission'),
 ('COMP 423','course','COMP 280','any','COMP 280 or instructor permission'),
 ('COMP 423','permission',None,'any','COMP 280 or instructor permission'),
 ('COMP 440','course','COMP 285','all','COMP 285'),
 ('COMP 454','course','COMP 280','all','COMP 280'),
 ('COMP 469','course','COMP 350','any','COMP 350 or instructor permission'),
 ('COMP 469','permission',None,'any','COMP 350 or instructor permission'),
 ('COMP 494','permission',None,'all','Instructor permission'),
 ('COMP 411','course','COMP 410','all','COMP 410'),
 ('COMP 452','course','COMP 285','all','COMP 285'),
 ('COMP 453','course','COMP 285','all','COMP 285'),
 ('COMP 463','course','COMP 285','all','COMP 285 and COMP 375'),
 ('COMP 463','course','COMP/ECEN 375','all','COMP 285 and COMP 375'),
 ('COMP 468','course','COMP 280','any','COMP 280 or instructor permission'),
 ('COMP 468','permission',None,'any','COMP 280 or instructor permission'),
 ('COMP 485','permission',None,'all','Instructor permission')]

# Keywords and expected course preferences are hand-authored test fixtures,
# not student data. One expected course is associated with each small test case.
TEST_CASES = [
 {'id':'T1','interest':'cybersecurity','completed':['COMP 163','COMP 280','COMP 285'],'standing':'junior','expected':'COMP 321'},
 {'id':'T2','interest':'data analytics','completed':['COMP 163','COMP 280','MATH 351'],'standing':'junior','expected':'COMP 361'},
 {'id':'T3','interest':'game design','completed':['COMP 163','COMP 280','COMP 285'],'standing':'junior','expected':'COMP 440'},
 {'id':'T4','interest':'software testing','completed':['COMP 163','COMP 167','COMP 280','COMP 285','COMP 410'],'standing':'senior','expected':'COMP 411'},
 {'id':'T5','interest':'networks','completed':['COMP 163','COMP 280','COMP 285'],'standing':'junior','expected':'COMP 452'},
 {'id':'T6','interest':'computer systems','completed':['COMP 163','COMP 280','COMP 350','COMP/ECEN 375'],'standing':'junior','expected':'COMP 469'}]

DDL = '''
PRAGMA foreign_keys=ON;
DROP TABLE IF EXISTS prerequisite_rules;
DROP TABLE IF EXISTS course_programs;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS programs;
CREATE TABLE programs(program_id TEXT PRIMARY KEY, program_name TEXT NOT NULL, college TEXT NOT NULL DEFAULT 'College of Engineering');
CREATE TABLE courses(course_code TEXT PRIMARY KEY, title TEXT NOT NULL, credits INTEGER, category TEXT NOT NULL, source_url TEXT NOT NULL, source_section TEXT NOT NULL);
CREATE TABLE course_programs(course_code TEXT NOT NULL REFERENCES courses(course_code), program_id TEXT NOT NULL REFERENCES programs(program_id), PRIMARY KEY(course_code,program_id));
CREATE TABLE prerequisite_rules(rule_id INTEGER PRIMARY KEY, course_code TEXT NOT NULL REFERENCES courses(course_code), rule_type TEXT NOT NULL CHECK(rule_type IN ('course','standing','permission','other')), prerequisite_course TEXT, logic_group TEXT NOT NULL CHECK(logic_group IN ('all','any')), rule_text TEXT NOT NULL);
'''

HANDBOOK='https://www.ncat.edu/coe/departments/cs/undergrad-programs/cs-undergraduate-handbook-2025.pdf'
GUIDE='https://www.ncat.edu/provost/academic-affairs/curriculum-guides/coe.php'

def make_db(path=DB_PATH):
    if Path(path).exists(): Path(path).unlink()
    conn=sqlite3.connect(path)
    conn.executescript(DDL)
    conn.executemany('INSERT INTO programs(program_id,program_name) VALUES (?,?)',PROGRAMS)
    for code,title,credits,category,tags in COURSES:
        section='Required Computer Science & Computer Programming Courses' if category=='required' else ('Computer Science Electives' if category=='elective' else 'Computer Science Electives Offered in other Departments')
        conn.execute('INSERT INTO courses VALUES (?,?,?,?,?,?)',(code,title,credits,category,HANDBOOK,section))
        conn.execute('INSERT INTO course_programs VALUES (?,?)',(code,'BS-CS'))
    conn.executemany('INSERT INTO prerequisite_rules(course_code,rule_type,prerequisite_course,logic_group,rule_text) VALUES (?,?,?,?,?)',PREREQUISITES)
    conn.commit()
    return conn

def is_eligible(course, completed, standing, permitted=False):
    rules=[r for r in PREREQUISITES if r[0]==course]
    if not rules: return True
    grouped={}
    for _,typ,pre,logic,text in rules:
        grouped.setdefault(logic,[]).append((typ,pre,text))
    # Each 'any' group can be satisfied by one option; all rows in an 'all'
    # group are required. Permission/standing and non-course checks are only
    # used when explicitly represented by the test case; unknown stays blocked.
    for logic,items in grouped.items():
        tests=[]
        for typ,pre,rule_text in items:
            if typ=='course': tests.append(pre in completed)
            elif typ=='standing': tests.append(standing in ('junior','senior'))
            elif typ=='permission': tests.append(permitted)
            else: tests.append(False)
        if logic=='all' and not all(tests): return False
        if logic=='any' and not any(tests): return False
    return True

def recommend(conn, interest, completed, standing, limit=3):
    rows=conn.execute('SELECT course_code,title FROM courses WHERE category IN (\'elective\',\'outside elective\')').fetchall()
    done=set(completed)
    choices=[]
    words=set(interest.lower().replace('-', ' ').split())
    for code,title in rows:
        if code in done or not is_eligible(code,done,standing): continue
        tags=set(dict((c[0],c[4].split(',')) for c in COURSES)[code])
        score=sum(1 for word in words if word in tags or word.rstrip('s') in tags)
        # exact keyword ties use course code for repeatability
        choices.append((score,code,title))
    choices.sort(key=lambda x:(-x[0],x[1]))
    return [{'course_code':c,'title':t,'score':s} for s,c,t in choices[:limit]]

def baseline(conn, completed, standing, limit=3):
    rows=conn.execute('SELECT course_code,title FROM courses WHERE category IN (\'elective\',\'outside elective\') ORDER BY course_code').fetchall()
    return [{'course_code':c,'title':t,'score':0} for c,t in rows if c not in set(completed) and is_eligible(c,set(completed),standing)][:limit]

def run_tests(conn):
    out=[]
    for tc in TEST_CASES:
        ours=recommend(conn,tc['interest'],tc['completed'],tc['standing'])
        base=baseline(conn,tc['completed'],tc['standing'])
        out.append({'id':tc['id'],'interest':tc['interest'],'expected':tc['expected'],
          'model_top3':[r['course_code'] for r in ours], 'baseline_top3':[r['course_code'] for r in base],
          'model_hit':tc['expected'] in [r['course_code'] for r in ours],
          'baseline_hit':tc['expected'] in [r['course_code'] for r in base]})
    return out

def export_csv(conn):
    rows=conn.execute('SELECT course_code,title,credits,category FROM courses ORDER BY course_code').fetchall()
    with open(CSV_PATH,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['course_code','title','credits','category']); w.writerows(rows)

def export_sql():
    conn=make_db()
    # deterministic readable SQL seed file from canonical tables
    lines=[DDL]
    for pid,name in PROGRAMS:
        lines.append('INSERT INTO programs(program_id,program_name) VALUES ('+','.join("'"+v.replace("'","''")+"'" for v in (pid,name))+');')
    for code,title,credits,category,tags in COURSES:
        section='Required Computer Science & Computer Programming Courses' if category=='required' else ('Computer Science Electives' if category=='elective' else 'Computer Science Electives Offered in other Departments')
        vals=[code,title,str(credits) if credits is not None else 'NULL',category,HANDBOOK,section]
        lines.append('INSERT INTO courses VALUES ('+','.join(('NULL' if v=='NULL' else "'"+str(v).replace("'","''")+"'") for v in vals)+');')
        lines.append("INSERT INTO course_programs VALUES ('"+code.replace("'","''")+"','BS-CS');")
    for course,typ,pre,logic,text in PREREQUISITES:
        vals=[course,typ,pre,logic,text]
        lines.append('INSERT INTO prerequisite_rules(course_code,rule_type,prerequisite_course,logic_group,rule_text) VALUES ('+','.join('NULL' if v is None else "'"+v.replace("'","''")+"'" for v in vals)+');')
    conn.close()
    SQL_PATH.write_text('\n'.join(lines)+'\n',encoding='utf-8')

def main():
    conn=make_db()
    export_csv(conn)
    export_sql()
    results=run_tests(conn)
    integrity=conn.execute('PRAGMA integrity_check').fetchone()[0]
    fk=conn.execute('PRAGMA foreign_key_check').fetchall()
    summary={'courses':conn.execute('SELECT COUNT(*) FROM courses').fetchone()[0],
      'programs':conn.execute('SELECT COUNT(*) FROM programs').fetchone()[0],
      'prerequisite_rules':conn.execute('SELECT COUNT(*) FROM prerequisite_rules').fetchone()[0],
      'foreign_key_issues':len(fk),'integrity_check':integrity,
      'test_cases':len(results),'model_hit_at_3':sum(x['model_hit'] for x in results)/len(results),
      'baseline_hit_at_3':sum(x['baseline_hit'] for x in results)/len(results),'cases':results}
    print(json.dumps(summary,indent=2))
    conn.close()

if __name__=='__main__': main()
