Aggie Course Guide - VS Code project

Open this folder in VS Code. The website is made from three files:
- index.html: the major-first welcome screen, course explorer, and chat layout
- styles.css: the responsive Aggie navy, gold, blue, and cream design
- app.js: the program list, sample course catalog, prerequisite checks, and suggestions

To try it, open index.html in a browser. If you use the Live Server extension, right-click index.html and choose Open with Live Server.

Choose a major first. Computer Science recommendations use the current 2025 handbook sample. Other majors are selectable but marked as not loaded yet. Suggestions currently use local topic matching; a live AI model is not connected. Always confirm course plans with an advisor.
