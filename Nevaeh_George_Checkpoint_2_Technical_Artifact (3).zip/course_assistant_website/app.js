// I keep the course info here so it's easy to check what the suggestions are based on.
const PROGRAMS = [
  {
    "id": "BS-AE",
    "name": "Architectural Engineering"
  },
  {
    "id": "BS-CE",
    "name": "Civil Engineering"
  },
  {
    "id": "BS-CS",
    "name": "Computer Science"
  },
  {
    "id": "BS-ME",
    "name": "Mechanical Engineering"
  },
  {
    "id": "BS-MEA",
    "name": "Mechanical Engineering (Aerospace)"
  },
  {
    "id": "BS-ISE",
    "name": "Industrial and Systems Engineering"
  },
  {
    "id": "BS-EE",
    "name": "Electrical Engineering"
  },
  {
    "id": "BS-CpE",
    "name": "Computer Engineering"
  },
  {
    "id": "BS-BIOE-G",
    "name": "Bioengineering (General)"
  },
  {
    "id": "BS-BIOE-I",
    "name": "Bioengineering (Innovation)"
  },
  {
    "id": "BS-BE-BP",
    "name": "Biological Engineering (Bioprocess Engineering)"
  },
  {
    "id": "BS-BE-NR",
    "name": "Biological Engineering (Natural Resources Engineering)"
  },
  {
    "id": "BS-CHE",
    "name": "Chemical Engineering"
  }
];
const COURSES = [
  {
    "code": "GEEN 111",
    "title": "College of Engineering Colloquium",
    "credits": 1,
    "category": "required",
    "tags": [
      "engineering",
      "career"
    ]
  },
  {
    "code": "COMP 121",
    "title": "Computer Science Freshmen Colloquium",
    "credits": 1,
    "category": "required",
    "tags": [
      "career"
    ]
  },
  {
    "code": "COMP 163",
    "title": "Introduction to Computer Programming",
    "credits": 3,
    "category": "required",
    "tags": [
      "programming",
      "software"
    ]
  },
  {
    "code": "COMP 167",
    "title": "Computer Programming Design",
    "credits": 3,
    "category": "required",
    "tags": [
      "programming",
      "software"
    ]
  },
  {
    "code": "COMP 180",
    "title": "Discrete Structures",
    "credits": 3,
    "category": "required",
    "tags": [
      "theory",
      "math"
    ]
  },
  {
    "code": "COMP 267",
    "title": "Data Base Design",
    "credits": 3,
    "category": "required",
    "tags": [
      "database",
      "data"
    ]
  },
  {
    "code": "COMP 200",
    "title": "Computer Science Sophomore Colloquium",
    "credits": 1,
    "category": "required",
    "tags": [
      "career"
    ]
  },
  {
    "code": "COMP 280",
    "title": "Data Structures",
    "credits": 3,
    "category": "required",
    "tags": [
      "programming",
      "algorithms"
    ]
  },
  {
    "code": "COMP 285",
    "title": "Design and Analysis of Algorithms",
    "credits": 3,
    "category": "required",
    "tags": [
      "algorithms",
      "theory"
    ]
  },
  {
    "code": "COMP 300",
    "title": "Computer Science Junior Colloquium",
    "credits": 1,
    "category": "required",
    "tags": [
      "career"
    ]
  },
  {
    "code": "COMP 322",
    "title": "Internet Systems",
    "credits": 3,
    "category": "required",
    "tags": [
      "networks",
      "systems"
    ]
  },
  {
    "code": "COMP 350",
    "title": "Operating Systems",
    "credits": 3,
    "category": "required",
    "tags": [
      "systems"
    ]
  },
  {
    "code": "COMP 360",
    "title": "Principles of Programming Languages",
    "credits": 3,
    "category": "required",
    "tags": [
      "programming",
      "theory"
    ]
  },
  {
    "code": "COMP 365",
    "title": "Artificial Intelligence and Machine Learning",
    "credits": 3,
    "category": "required",
    "tags": [
      "ai",
      "machine learning",
      "data"
    ]
  },
  {
    "code": "COMP/ECEN 375",
    "title": "Computer Architecture and Organization",
    "credits": 3,
    "category": "required",
    "tags": [
      "systems",
      "hardware"
    ]
  },
  {
    "code": "COMP 385",
    "title": "Theory of Computing",
    "credits": 3,
    "category": "required",
    "tags": [
      "theory"
    ]
  },
  {
    "code": "COMP 390",
    "title": "Social Implications of Computing",
    "credits": 3,
    "category": "required",
    "tags": [
      "ethics",
      "society"
    ]
  },
  {
    "code": "COMP 410",
    "title": "Software Engineering",
    "credits": 3,
    "category": "required",
    "tags": [
      "software",
      "teamwork"
    ]
  },
  {
    "code": "COMP 476",
    "title": "Networked Computer Systems",
    "credits": 3,
    "category": "required",
    "tags": [
      "networks",
      "systems"
    ]
  },
  {
    "code": "COMP 495",
    "title": "Senior Project I",
    "credits": 3,
    "category": "required",
    "tags": [
      "software",
      "teamwork"
    ]
  },
  {
    "code": "COMP 496",
    "title": "Senior Project II",
    "credits": 3,
    "category": "required",
    "tags": [
      "software",
      "teamwork"
    ]
  },
  {
    "code": "COMP 320",
    "title": "Fundamentals of Cybersecurity",
    "credits": null,
    "category": "elective",
    "tags": [
      "security",
      "cybersecurity"
    ]
  },
  {
    "code": "COMP 321",
    "title": "Computer System Security",
    "credits": null,
    "category": "elective",
    "tags": [
      "security",
      "cybersecurity",
      "systems"
    ]
  },
  {
    "code": "COMP 323",
    "title": "Introduction to Health Care Information Systems",
    "credits": null,
    "category": "elective",
    "tags": [
      "health",
      "data"
    ]
  },
  {
    "code": "COMP 340",
    "title": "Game Intelligence",
    "credits": null,
    "category": "elective",
    "tags": [
      "games",
      "ai"
    ]
  },
  {
    "code": "COMP 356",
    "title": "Computational Hip-Hop and Object-Oriented Design",
    "credits": null,
    "category": "elective",
    "tags": [
      "programming",
      "design"
    ]
  },
  {
    "code": "COMP 361",
    "title": "Data Analytics in Python",
    "credits": null,
    "category": "elective",
    "tags": [
      "data",
      "analytics",
      "python"
    ]
  },
  {
    "code": "COMP 363",
    "title": "Object Oriented Programming",
    "credits": null,
    "category": "elective",
    "tags": [
      "programming"
    ]
  },
  {
    "code": "COMP 368",
    "title": "Object-Oriented Software Development",
    "credits": null,
    "category": "elective",
    "tags": [
      "software",
      "design"
    ]
  },
  {
    "code": "COMP 420",
    "title": "Applied Network Security",
    "credits": null,
    "category": "elective",
    "tags": [
      "security",
      "cybersecurity",
      "networks"
    ]
  },
  {
    "code": "COMP 421",
    "title": "Security Management for Information Systems",
    "credits": null,
    "category": "elective",
    "tags": [
      "security",
      "cybersecurity",
      "management"
    ]
  },
  {
    "code": "COMP 422",
    "title": "Information Privacy and Security",
    "credits": null,
    "category": "elective",
    "tags": [
      "security",
      "privacy"
    ]
  },
  {
    "code": "COMP 423",
    "title": "Web Security",
    "credits": null,
    "category": "elective",
    "tags": [
      "security",
      "cybersecurity",
      "web"
    ]
  },
  {
    "code": "COMP 440",
    "title": "Game Design",
    "credits": null,
    "category": "elective",
    "tags": [
      "games",
      "design"
    ]
  },
  {
    "code": "COMP 454",
    "title": "Virtual and Augmented Reality",
    "credits": null,
    "category": "elective",
    "tags": [
      "games",
      "graphics"
    ]
  },
  {
    "code": "COMP 469",
    "title": "Introduction to Parallel Programming",
    "credits": null,
    "category": "elective",
    "tags": [
      "programming",
      "systems"
    ]
  },
  {
    "code": "COMP 494",
    "title": "Independent Study",
    "credits": null,
    "category": "elective",
    "tags": [
      "research"
    ]
  },
  {
    "code": "COMP 411",
    "title": "Introduction to System Testing and Evaluation",
    "credits": null,
    "category": "elective",
    "tags": [
      "software",
      "testing"
    ]
  },
  {
    "code": "COMP 452",
    "title": "Network Science",
    "credits": null,
    "category": "elective",
    "tags": [
      "networks",
      "data"
    ]
  },
  {
    "code": "COMP 453",
    "title": "Introduction to Computer Graphics",
    "credits": null,
    "category": "elective",
    "tags": [
      "graphics",
      "games"
    ]
  },
  {
    "code": "COMP 463",
    "title": "Introduction to Compiler Design",
    "credits": null,
    "category": "elective",
    "tags": [
      "programming",
      "systems"
    ]
  },
  {
    "code": "COMP 468",
    "title": "Introduction to Data Mining",
    "credits": null,
    "category": "elective",
    "tags": [
      "data",
      "analytics"
    ]
  },
  {
    "code": "COMP 485",
    "title": "Special Topics in Computer Science",
    "credits": null,
    "category": "elective",
    "tags": [
      "research"
    ]
  },
  {
    "code": "BUAN 335",
    "title": "Management of Information Resources",
    "credits": null,
    "category": "outside elective",
    "tags": [
      "management",
      "data"
    ]
  },
  {
    "code": "ECEN 427",
    "title": "Introduction to Microprocessors",
    "credits": null,
    "category": "outside elective",
    "tags": [
      "hardware",
      "systems"
    ]
  },
  {
    "code": "ISEN 415",
    "title": "Discrete Event Systems Model Simulation",
    "credits": null,
    "category": "outside elective",
    "tags": [
      "simulation",
      "systems"
    ]
  },
  {
    "code": "MATH 365",
    "title": "Introduction to Data Science",
    "credits": null,
    "category": "outside elective",
    "tags": [
      "data",
      "analytics"
    ]
  },
  {
    "code": "CST 340",
    "title": "Introduction to Mainframe Operations",
    "credits": null,
    "category": "outside elective",
    "tags": [
      "systems"
    ]
  }
];
const PREREQUISITES = {
  "COMP 320": [
    {
      "course": null,
      "type": "standing",
      "logic": "all",
      "text": "Junior standing"
    }
  ],
  "COMP 321": [
    {
      "course": "COMP 285",
      "type": "course",
      "logic": "all",
      "text": "COMP 285"
    }
  ],
  "COMP 323": [
    {
      "course": null,
      "type": "standing",
      "logic": "all",
      "text": "Junior standing"
    }
  ],
  "COMP 340": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "all",
      "text": "COMP 280"
    }
  ],
  "COMP 356": [
    {
      "course": "COMP 163",
      "type": "course",
      "logic": "any",
      "text": "COMP 163 or instructor permission"
    },
    {
      "course": null,
      "type": "permission",
      "logic": "any",
      "text": "COMP 163 or instructor permission"
    }
  ],
  "COMP 361": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "all",
      "text": "COMP 280, MATH 351, and a statistics elective"
    },
    {
      "course": "MATH 351",
      "type": "course",
      "logic": "all",
      "text": "COMP 280, MATH 351, and a statistics elective"
    },
    {
      "course": null,
      "type": "other",
      "logic": "all",
      "text": "Statistics elective"
    }
  ],
  "COMP 363": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "all",
      "text": "COMP 280"
    }
  ],
  "COMP 368": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "all",
      "text": "COMP 280"
    }
  ],
  "COMP 420": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    },
    {
      "course": null,
      "type": "permission",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    }
  ],
  "COMP 421": [
    {
      "course": "COMP 285",
      "type": "course",
      "logic": "all",
      "text": "COMP 285"
    }
  ],
  "COMP 422": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    },
    {
      "course": null,
      "type": "permission",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    }
  ],
  "COMP 423": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    },
    {
      "course": null,
      "type": "permission",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    }
  ],
  "COMP 440": [
    {
      "course": "COMP 285",
      "type": "course",
      "logic": "all",
      "text": "COMP 285"
    }
  ],
  "COMP 454": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "all",
      "text": "COMP 280"
    }
  ],
  "COMP 469": [
    {
      "course": "COMP 350",
      "type": "course",
      "logic": "any",
      "text": "COMP 350 or instructor permission"
    },
    {
      "course": null,
      "type": "permission",
      "logic": "any",
      "text": "COMP 350 or instructor permission"
    }
  ],
  "COMP 494": [
    {
      "course": null,
      "type": "permission",
      "logic": "all",
      "text": "Instructor permission"
    }
  ],
  "COMP 411": [
    {
      "course": "COMP 410",
      "type": "course",
      "logic": "all",
      "text": "COMP 410"
    }
  ],
  "COMP 452": [
    {
      "course": "COMP 285",
      "type": "course",
      "logic": "all",
      "text": "COMP 285"
    }
  ],
  "COMP 453": [
    {
      "course": "COMP 285",
      "type": "course",
      "logic": "all",
      "text": "COMP 285"
    }
  ],
  "COMP 463": [
    {
      "course": "COMP 285",
      "type": "course",
      "logic": "all",
      "text": "COMP 285 and COMP 375"
    },
    {
      "course": "COMP/ECEN 375",
      "type": "course",
      "logic": "all",
      "text": "COMP 285 and COMP 375"
    }
  ],
  "COMP 468": [
    {
      "course": "COMP 280",
      "type": "course",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    },
    {
      "course": null,
      "type": "permission",
      "logic": "any",
      "text": "COMP 280 or instructor permission"
    }
  ],
  "COMP 485": [
    {
      "course": null,
      "type": "permission",
      "logic": "all",
      "text": "Instructor permission"
    }
  ]
};
const SOURCE = "https://www.ncat.edu/coe/departments/cs/undergrad-programs/cs-undergraduate-handbook-2025.pdf";

// The major list covers Engineering, but the course details I have loaded right now are for CS.
const SUPPORTED_MAJOR = "BS-CS";

const form = document.getElementById("chatForm");
const questionInput = document.getElementById("question");
const completedInput = document.getElementById("completed");
const programSelect = document.getElementById("program");
const standingSelect = document.getElementById("standing");
const messages = document.getElementById("messages");
const topicChips = document.getElementById("topicChips");

function normalizeCourseCode(value) {
  return String(value || "").trim().toUpperCase().replace(/\s+/g, " ");
}

// Fill the major dropdown from the same program list used by the recommender.
PROGRAMS.forEach((program) => {
  const option = document.createElement("option");
  option.value = program.id;
  option.textContent = program.name;
  programSelect.append(option);
});

const majorGate = document.getElementById("majorGate");
const appShell = document.getElementById("appShell");
const mainApp = document.getElementById("mainApp");
const unsupportedPanel = document.getElementById("unsupported");

// I ask for the major first. If we don't have that program's courses yet, I say so here.
document.getElementById("continueButton").addEventListener("click", () => {
  if (!programSelect.value) {
    programSelect.focus();
    return;
  }

  const chosenProgram = PROGRAMS.find((program) => program.id === programSelect.value);
  majorGate.hidden = true;
  appShell.hidden = false;
  document.getElementById("chosenMajor").textContent = chosenProgram?.name || "Engineering";

  if (programSelect.value === SUPPORTED_MAJOR) {
    unsupportedPanel.hidden = true;
    mainApp.hidden = false;
    showWelcome();
    return;
  }

  mainApp.hidden = true;
  unsupportedPanel.hidden = false;
  document.getElementById("unsupportedText").textContent =
    `I haven't added the ${chosenProgram?.name || "selected"} course guide yet. Right now, the course details are for Computer Science. You can go back and choose that major to try the recommendations.`;
});

function returnToMajorPicker() {
  appShell.hidden = true;
  majorGate.hidden = false;
  programSelect.focus();
}

document.getElementById("chooseAnother").addEventListener("click", returnToMajorPicker);
document.getElementById("changeMajorTop").addEventListener("click", returnToMajorPicker);

const coursesByCode = new Map(COURSES.map((course) => [normalizeCourseCode(course.code), course]));
const courseOptions = document.getElementById("courseOptions");

COURSES.filter((course) => course.category === "required").forEach((course) => {
  const option = document.createElement("option");
  option.value = `${course.code} - ${course.title}`;
  courseOptions.append(option);
});

// These buttons save a little typing for common prerequisite courses.
["COMP 163", "COMP 280", "COMP 285", "MATH 351"].forEach((courseCode) => {
  const button = document.createElement("button");
  button.type = "button";
  button.className = "chip";
  button.textContent = `+ ${courseCode}`;
  button.addEventListener("click", () => {
    const completed = completedInput.value.split(",").map((course) => course.trim()).filter(Boolean);
    const alreadyAdded = completed.some((course) => normalizeCourseCode(course) === courseCode);
    if (!alreadyAdded) completed.push(courseCode);
    completedInput.value = completed.join(", ");
  });
  document.getElementById("quickCourses").append(button);
});

function getCompletedCourses() {
  const entries = completedInput.value.split(",").map((course) => course.trim()).filter(Boolean);
  const completed = new Set();

  entries.forEach((entry) => {
    const code = normalizeCourseCode(entry.split(" - ")[0]);
    if (coursesByCode.has(code)) {
      completed.add(code);
      return;
    }

    // Keep a correctly formatted course code even if it's not in this small sample list.
    if (/^[A-Z]{2,5}\s?\d{3}$/.test(code)) {
      completed.add(code.replace(/([A-Z]+)(\d+)/, "$1 $2"));
    }
  });

  if (document.getElementById("stats").checked) {
    completed.add("STATISTICS ELECTIVE");
  }
  return completed;
}

function meetsPrerequisites(courseCode, completed, standing, hasPermission) {
  const rules = PREREQUISITES[courseCode] || [];
  if (rules.length === 0) return true;

  // Some courses accept either of two options, while others need every listed requirement.
  const ruleGroups = {};
  rules.forEach((rule) => {
    (ruleGroups[rule.logic] ??= []).push(rule);
  });

  return Object.entries(ruleGroups).every(([logic, group]) => {
    const checks = group.map((rule) => {
      if (rule.type === "course") return completed.has(normalizeCourseCode(rule.course));
      if (rule.type === "standing") return ["junior", "senior"].includes(standing);
      if (rule.type === "permission") return hasPermission;
      if (rule.type === "other") return completed.has("STATISTICS ELECTIVE");
      return false;
    });

    return logic === "all" ? checks.every(Boolean) : checks.some(Boolean);
  });
}

function findTopicTags(text) {
  const matches = [
    [/cyber|secur|privacy/i, ["security", "cybersecurity", "privacy"]],
    [/data|analytic|machine learning|\bai\b|artificial intelligence/i, ["data", "analytics", "ai", "machine learning"]],
    [/game|gaming|design/i, ["games", "design"]],
    [/network/i, ["networks"]],
    [/software|testing|quality/i, ["software", "testing"]],
    [/system|operating system|parallel/i, ["systems"]],
    [/graphic|visual|vr|augmented/i, ["graphics", "games"]],
    [/hardware|microprocessor/i, ["hardware", "systems"]],
    [/ethic|society|social/i, ["ethics", "society"]],
    [/python/i, ["python", "data"]],
  ];
  const tags = new Set();
  matches.forEach(([pattern, topicTags]) => {
    if (pattern.test(text)) topicTags.forEach((tag) => tags.add(tag));
  });
  return tags;
}

function getSuggestions(interest, question, completed, standing, hasPermission) {
  if (programSelect.value !== SUPPORTED_MAJOR) {
    throw new Error("I only have course details loaded for Computer Science right now.");
  }

  // This version matches familiar topic words to course tags; it isn't using a live AI model.
  const tags = findTopicTags(`${interest} ${question}`);
  if (tags.size === 0) {
    throw new Error("I didn't recognize that topic yet. Try cybersecurity, data analytics, games, software testing, networks, or systems.");
  }

  return COURSES
    .filter((course) => ["elective", "outside elective"].includes(course.category))
    .filter((course) => !completed.has(normalizeCourseCode(course.code)))
    .filter((course) => meetsPrerequisites(course.code, completed, standing, hasPermission))
    .map((course) => ({
      course,
      score: course.tags.reduce((total, tag) => total + Number(tags.has(tag)), 0),
    }))
    .filter((result) => result.score > 0)
    .sort((first, second) => second.score - first.score || first.course.code.localeCompare(second.course.code))
    .slice(0, 3);
}

function addMessage(kind, text) {
  const bubble = document.createElement("div");
  bubble.className = `bubble ${kind}`;
  bubble.textContent = text;
  messages.append(bubble);
  messages.scrollTop = messages.scrollHeight;
  return bubble;
}

function showWelcome() {
  messages.replaceChildren();
  addMessage("assistant", "Hey! What are you curious about? I'll look for courses that connect to it and check the prerequisites against the classes you've taken.");
  topicChips.replaceChildren();

  ["Cybersecurity", "Data analytics", "Software testing", "Game design"].forEach((topic) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "chip";
    button.textContent = topic;
    button.addEventListener("click", () => {
      document.getElementById("interest").value = topic.toLowerCase();
      questionInput.value = `What courses connect to ${topic.toLowerCase()}?`;
      form.requestSubmit();
    });
    topicChips.append(button);
  });
}

function showAnswer(question, results) {
  addMessage("student", question || "Can you suggest a few courses for me?");
  const answer = addMessage("assistant", "");

  if (results.length === 0) {
    answer.textContent = "I didn't find a course that fits that topic and your current course history. Try another topic or double-check the classes you entered.";
    return;
  }

  const intro = document.createElement("p");
  intro.textContent = "Based on what you entered, these are the courses I'd look into:";
  answer.append(intro);

  const courseCards = document.createElement("div");
  courseCards.className = "recommendations";

  results.forEach(({ course }) => {
    const card = document.createElement("article");
    card.className = "course";

    const top = document.createElement("div");
    top.className = "course-top";
    const title = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = course.title;
    const code = document.createElement("div");
    code.className = "course-code";
    code.textContent = course.code + (course.credits ? ` · ${course.credits} credits` : "");
    title.append(heading, code);

    const match = document.createElement("span");
    match.className = "match";
    match.textContent = "Topic match";
    top.append(title, match);
    card.append(top);

    const rules = PREREQUISITES[course.code] || [];
    const note = document.createElement("div");
    note.className = "course-note";
    note.textContent = rules.length
      ? "Handbook prerequisite: " + [...new Set(rules.map((rule) => rule.text))].join("; ") + "."
      : "I don't have a prerequisite rule for this course in the loaded data. Check with the department before registering.";
    card.append(note);
    courseCards.append(card);
  });

  answer.append(courseCards);
  const sourceNote = document.createElement("div");
  sourceNote.className = "source";
  const sourceLink = document.createElement("a");
  sourceLink.href = SOURCE;
  sourceLink.target = "_blank";
  sourceLink.rel = "noreferrer";
  sourceLink.textContent = "Check the course handbook";
  sourceNote.append(sourceLink);
  answer.append(sourceNote);
}

function askForCourses(question) {
  const completed = getCompletedCourses();
  const results = getSuggestions(
    document.getElementById("interest").value,
    question,
    completed,
    standingSelect.value,
    document.getElementById("permission").checked,
  );
  showAnswer(question, results);

  return results.map(({ course, score }) => ({
    courseCode: course.code,
    title: course.title,
    matchScore: score,
    prerequisites: [...new Set((PREREQUISITES[course.code] || []).map((rule) => rule.text))],
  }));
}

form.addEventListener("submit", (event) => {
  event.preventDefault();
  try {
    askForCourses(questionInput.value.trim());
  } catch (error) {
    addMessage("assistant", error.message || String(error));
  }
});

// If an AI tool is available in the page's environment, it can call this same recommender.
const modelContext = document.documentElement ? document.modelContext : undefined;
if (modelContext?.registerTool) {
  const lifecycle = new AbortController();
  try {
    Promise.resolve(modelContext.registerTool({
      name: "recommend_courses",
      title: "Recommend courses",
      description: "Show up to three eligible NC A&T Computer Science courses based on a student's topic, completed courses, and class standing. Only Computer Science course data is loaded.",
      inputSchema: {
        type: "object",
        properties: {
          programId: { type: "string", enum: PROGRAMS.map((program) => program.id) },
          question: { type: "string" },
          interest: { type: "string" },
          completedCourses: { type: "array", items: { type: "string" } },
          standing: { type: "string", enum: ["freshman", "sophomore", "junior", "senior"] },
          hasStatisticsElective: { type: "boolean" },
          hasInstructorPermission: { type: "boolean" },
        },
        required: ["programId", "question", "interest", "completedCourses", "standing"],
        additionalProperties: false,
      },
      annotations: { readOnlyHint: false, untrustedContentHint: true },
      execute(input) {
        if (
          !input ||
          !PROGRAMS.some((program) => program.id === input.programId) ||
          typeof input.question !== "string" ||
          typeof input.interest !== "string" ||
          !Array.isArray(input.completedCourses) ||
          !["freshman", "sophomore", "junior", "senior"].includes(input.standing)
        ) {
          throw new Error("Please include your major, question, interest, completed classes, and year.");
        }

        if (programSelect.value !== input.programId) {
          programSelect.value = input.programId;
          document.getElementById("continueButton").click();
        }
        if (input.programId !== SUPPORTED_MAJOR) {
          throw new Error("I only have course details loaded for Computer Science right now.");
        }

        completedInput.value = input.completedCourses.join(", ");
        document.getElementById("stats").checked = Boolean(input.hasStatisticsElective);
        document.getElementById("permission").checked = Boolean(input.hasInstructorPermission);
        standingSelect.value = input.standing;
        document.getElementById("interest").value = input.interest;
        const recommendations = askForCourses(input.question);
        return { recommendations, visibleResultUpdated: true };
      },
    }, { signal: lifecycle.signal })).catch(() => {});

    window.addEventListener("pagehide", () => lifecycle.abort(), { once: true });
  } catch {
    // The page still works normally if this optional connection isn't available.
  }
}
