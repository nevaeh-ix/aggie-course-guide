import sqlite3
import unittest
from pathlib import Path
import course_recommender as app

class CourseDatabaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.db=app.make_db(Path(__file__).with_name('test_tmp.sqlite'))

    @classmethod
    def tearDownClass(cls):
        cls.db.close()
        Path(__file__).with_name('test_tmp.sqlite').unlink(missing_ok=True)

    def test_database_integrity_and_seed_counts(self):
        self.assertEqual(self.db.execute('PRAGMA integrity_check').fetchone()[0],'ok')
        self.assertEqual(self.db.execute('PRAGMA foreign_key_check').fetchall(),[])
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM programs').fetchone()[0],13)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM courses').fetchone()[0],48)
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM prerequisite_rules').fetchone()[0],31)

    def test_course_program_rows_use_known_ids(self):
        self.assertEqual(self.db.execute('SELECT COUNT(*) FROM course_programs').fetchone()[0],48)
        self.assertEqual(self.db.execute("SELECT COUNT(*) FROM course_programs WHERE program_id='BS-CS'").fetchone()[0],48)

    def test_recommendations_never_repeat_completed_courses(self):
        tc=app.TEST_CASES[0]
        rows=app.recommend(self.db,tc['interest'],tc['completed'],tc['standing'])
        self.assertTrue(set(x['course_code'] for x in rows).isdisjoint(tc['completed']))

    def test_same_six_cases_show_the_weak_prerequisite_case(self):
        results=app.run_tests(self.db)
        self.assertEqual(len(results),6)
        self.assertEqual(sum(x['model_hit'] for x in results),5)
        self.assertEqual(sum(x['baseline_hit'] for x in results),1)
        case2=next(x for x in results if x['id']=='T2')
        self.assertFalse(case2['model_hit'])
        self.assertNotIn('COMP 361',case2['model_top3'])

if __name__=='__main__': unittest.main(verbosity=2)
