NC A&T College of Engineering Course Recommendation System
Practical Checkpoint 2 - Technical Artifact
Student: Nevaeh George

Files
- NCAT_COE_Course_Recommendation_Checkpoint2.ipynb: executed notebook with seed, data checks, comparison, and weak case.
- ncat_coe_course_database.sql: SQLite-compatible schema and seed inserts.
- ncat_coe_courses.sqlite: ready-to-query SQLite database.
- courses.csv: current course table export.
- course_recommender.py: database generation and recommendation prototype.
- test_course_recommender.py: repeatable structural and behavior tests.
- results.json: captured same-case baseline comparison.
- course_assistant_website/: complete website source with separate index.html, styles.css, and app.js files. Open that folder in VS Code, then open index.html in a browser to try it.

Run from this folder with Python 3:
  python course_recommender.py
  python -m unittest test_course_recommender.py -v

Scope and data notes
The College of Engineering program table includes the 13 undergraduate programs on the 2025-2026 official guide. The HTML/CSS/JavaScript interface asks students to choose a major first; course suggestions currently work for Computer Science only, and other majors are labeled as not loaded. Course rows and prerequisite rules currently come from the 2025 Computer Science Undergraduate Handbook only. All 48 seeded courses are associated with the Computer Science BS program. Credits are left blank where the handbook's elective list does not give a credit value. The six expected test preferences are hand-authored fixtures, not real student feedback. Recommendation tags are also manually assigned.

Official source pages
College of Engineering 2025-2026 curriculum guides:
https://www.ncat.edu/provost/academic-affairs/curriculum-guides/coe.php
Computer Science Undergraduate Handbook (2025):
https://www.ncat.edu/coe/departments/cs/undergrad-programs/cs-undergraduate-handbook-2025.pdf

AI disclosure
ChatGPT assisted with code structure, test setup, report drafting, and the interface. The interface does not call a live AI model; it ranks tagged catalog courses using local matching logic. No external recommendation model or third-party code library is used by the recommender. The database uses Python's built-in sqlite3 and CSV libraries.
